package com.ssafy.test;

public class BeanTest {

}
