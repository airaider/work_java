package com.java.first;

public class CircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.printf("반지름이 5Cm인 원의 넓이는 %.2fCm2 입니다", 5*5*3.14);
	}

}
