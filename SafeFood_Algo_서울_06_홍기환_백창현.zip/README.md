# B반 관통 프로젝트(알고리즘)
팀원 : 홍기환, 백창현 <br>
기간 : 2019.10.02

## 프로젝트 목표

구현해야 할 기능
1) 알고리즘 2개 이상 구현 및 적용
- - -

## 식품 오름차순 정렬 (번호, 이름, 칼로리)
- 번호 정렬
![번호 정렬](./capture/번호정렬.JPG)
- 이름 정렬
![이름 정렬](./capture/이름정렬.JPG)
- 칼로리 정렬
![칼로리 정렬](./capture/칼로리정렬.JPG)

```
private String sort(HttpServletRequest request, HttpServletResponse response) {
		String type = request.getParameter("sort");
		System.out.println(type);
		switch (type) {
		case "no":
			request.setAttribute("list", foodService.searchAll());
			break;
		case "name":
			List<Food> food = foodService.searchAll();
			Collections.sort(food, new Comparator<Food>() {
				@Override
				public int compare(Food o1, Food o2) {
					return o1.getName().compareTo(o2.getName());
				}
			});
			request.setAttribute("list", food);
			break;
		case "kal":
			List<Food> food2 = foodService.searchAll();
			Collections.sort(food2, new Comparator<Food>() {
				@Override
				public int compare(Food o1, Food o2) {
					return o1.getNutr_cont1().compareTo(o2.getNutr_cont1());
				}
			});
			request.setAttribute("list", food2);
			break;
		default:
			break;
		}
		return "Main.jsp";
	}
```

## 식품 내림차순 정렬 (번호, 이름, 칼로리)
- 번호 정렬
![번호 정렬](./capture/번호정렬2.JPG)
- 이름 정렬
![이름 정렬](./capture/이름정렬2.JPG)
- 칼로리 정렬
![칼로리 정렬](./capture/칼로리정렬2.JPG)

```
if(tt.equals("내림차순")) {
			System.out.println("!!");
			Collections.reverse(food);
		}
```

## 추천 상품 (KMP 알고리즘)
> 사용자 회원가입 시 기입한 알레르기 성분 제외한 식품 결과 추천 
- 로그인 이후 화면
![추천 버튼](./capture/추천.JPG)
- 추천 이후 화면
![추천 결과](./capture/추천후.JPG)

```
public class KMP {
	public static boolean KMPSearch(String pat, String[] txt) 
    { 
		for(String temp : txt) {
		
		char[] T = pat.toCharArray();
		char[] P = temp.toCharArray();
		
		int tLength = T.length, pLength= P.length;
		int[] fail  = new int[pLength];
		
		for (int i = 1,j=0; i < pLength; ++i) {
			
			while(j>0 && P[i] != P[j]) j = fail[j-1];
			
			if(P[i]==P[j]) fail[i] = ++j;
		}
		
		int cnt=0;
		for (int i = 0, j=0; i < tLength; ++i) {

			while(j>0 && T[i] != P[j]) j = fail[j-1];
			
			if(T[i] == P[j]) {
				if(j == pLength-1) { 
					cnt++;
					j = fail[j];
				}else {
					++j;
				}
			}
			if(cnt>0) {
				return true;
			}
		}
		}
		return false;
    }
}
```

```
private String filter(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		String material = memberService.search((String)session.getAttribute("id")).getMaterial();
		String[] mat = material.split(",");
		List<Food> result = new LinkedList<Food>();
		List<Food> food = foodService.searchAll();
		
		for (int i = 0, size=food.size(); i < size; i++) {
			String input = food.get(i).getMaterial()+ food.get(i).getName();
			if(!KMP.KMPSearch(input,mat)) {
				result.add(food.get(i));
			}
		}
		request.setAttribute("list", result);
		return "Main.jsp";
	}
```

## 회원 비밀번호 암호화 (AES 256)
```
public class AES256Util {
	private String iv;
	private Key keySpec;

	/**
	 * * 16자리의 키값을 입력하여 객체를 생성한다. * @param key 암/복호화를 위한 키값 * @throws
	 * UnsupportedEncodingException 키값의 길이가 16이하일 경우 발생
	 */
	public AES256Util(String key) throws UnsupportedEncodingException {
		this.iv = key.substring(0, 16);
		byte[] keyBytes = new byte[16];
		byte[] b = key.getBytes("UTF-8");
		int len = b.length;
		if (len > keyBytes.length) {
			len = keyBytes.length;
		}
		System.arraycopy(b, 0, keyBytes, 0, len);
		SecretKeySpec keySpec = new SecretKeySpec(keyBytes, "AES");
		this.keySpec = keySpec;
	}

	/**
	 * * AES256 으로 암호화 한다. * @param str 암호화할 문자열 * @return * @throws
	 * NoSuchAlgorithmException * @throws GeneralSecurityException * @throws
	 * UnsupportedEncodingException
	 */
	public String encrypt(String str)
			throws NoSuchAlgorithmException, GeneralSecurityException, UnsupportedEncodingException {
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		c.init(Cipher.ENCRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes()));
		byte[] encrypted = c.doFinal(str.getBytes("UTF-8"));
		String enStr = new String(Base64.encodeBase64(encrypted));
		return enStr;
	}

	/**
	 * * AES256으로 암호화된 txt 를 복호화한다. * @param str 복호화할 문자열 * @return * @throws
	 * NoSuchAlgorithmException * @throws GeneralSecurityException * @throws
	 * UnsupportedEncodingException
	 */
	public String decrypt(String str)
			throws NoSuchAlgorithmException, GeneralSecurityException, UnsupportedEncodingException {
		Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding");
		c.init(Cipher.DECRYPT_MODE, keySpec, new IvParameterSpec(iv.getBytes()));
		byte[] byteStr = Base64.decodeBase64(str.getBytes());
		return new String(c.doFinal(byteStr), "UTF-8");
	}
}
```
