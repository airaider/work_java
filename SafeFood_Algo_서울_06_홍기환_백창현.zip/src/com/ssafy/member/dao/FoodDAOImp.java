package com.ssafy.member.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import com.ssafy.member.dto.Food;
import com.ssafy.util.DBUtil;

public class FoodDAOImp implements FoodDAO {

	public Food search(String type, String condition) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from food ";
			if(type.equals("name")) {
				sql += " where name like ? ";
				stmt = con.prepareStatement(sql);
				stmt.setString(1, condition);
			}else if(type.equals("meterial")) {
				sql += " where material like = ? ";
				stmt = con.prepareStatement(sql);
				stmt.setString(1, "%"+ condition + "%");
			}else if(type.equals("code")) {
				sql += " where code = ? ";
				stmt = con.prepareStatement(sql);
				stmt.setInt(1, Integer.parseInt(condition));
			}
			
			rs = stmt.executeQuery();
			if(rs.next()) {
				return new Food(rs.getInt("code")
								,rs.getString("name")
								,rs.getString("maker")
								,rs.getString("material")
								,rs.getString("image")
								,rs.getString("serving_wt")
								,rs.getString("nutr_cont1")
								,rs.getString("nutr_cont2")
								,rs.getString("nutr_cont3")
								,rs.getString("nutr_cont4")
								,rs.getString("nutr_cont5")
								,rs.getString("nutr_cont6")
								,rs.getString("nutr_cont7")
								,rs.getString("nutr_cont8")
								,rs.getString("nutr_cont9")
								,rs.getInt("bgn_year")
								,rs.getString("animal_plant"));
			}
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
		return null;
	}

	public List<Food> searchAll() throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		try {
			con = DBUtil.getConnection();
			String sql = " select * from food  ";
			stmt = con.prepareStatement(sql);
			rs = stmt.executeQuery();
			List<Food> foods = new LinkedList<Food>();
			while(rs.next()) {
				foods.add(new Food(rs.getInt("code")
						,rs.getString("name")
						,rs.getString("maker")
						,rs.getString("material")
						,rs.getString("image")
						,rs.getString("serving_wt")
						,rs.getString("nutr_cont1")
						,rs.getString("nutr_cont2")
						,rs.getString("nutr_cont3")
						,rs.getString("nutr_cont4")
						,rs.getString("nutr_cont5")
						,rs.getString("nutr_cont6")
						,rs.getString("nutr_cont7")
						,rs.getString("nutr_cont8")
						,rs.getString("nutr_cont9")
						,rs.getInt("bgn_year")
						,rs.getString("animal_plant")));
			}
			return foods;
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
	}

	public void add(Food food) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = "insert into food (name, maker, material, image, serving_wt, nutr_cont1, nutr_cont2, nutr_cont3, nutr_cont4, nutr_cont5, nutr_cont6, nutr_cont7, nutr_cont8, nutr_cont9, bgn_year, animal_plant) "
					+ " values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ";
			stmt = con.prepareStatement(sql);
			int idx = 1;
			stmt.setString(idx++, food.getName());		
			stmt.setString(idx++, food.getMaker());		
			stmt.setString(idx++, food.getMaterial());		
			stmt.setString(idx++, food.getImage());		
			stmt.setString(idx++, food.getServing_wt());		
			stmt.setString(idx++, food.getNutr_cont1());		
			stmt.setString(idx++, food.getNutr_cont2());		
			stmt.setString(idx++, food.getNutr_cont3());		
			stmt.setString(idx++, food.getNutr_cont4());		
			stmt.setString(idx++, food.getNutr_cont5());		
			stmt.setString(idx++, food.getNutr_cont6());		
			stmt.setString(idx++, food.getNutr_cont7());		
			stmt.setString(idx++, food.getNutr_cont8());		
			stmt.setString(idx++, food.getNutr_cont9());		
			stmt.setInt(idx++, food.getBgn_year());		
			stmt.setString(idx++, food.getAnimal_plant());		


			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	public void update(Food food) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		try {
			con = DBUtil.getConnection();
			String sql = " update food set serving_wt = ?, nutr_cont1 = ?, nutr_cont2 = ?, nutr_cont3 = ?, nutr_cont4 = ?, nutr_cont5 = ?, nutr_cont6 = ?, nutr_cont7 = ?, nutr_cont8 = ?, nutr_cont9 = ?, bgn_year = ? "
						+ " where name = ?";
			stmt = con.prepareStatement(sql);
			int idx = 1;
			stmt.setString(idx++, food.getServing_wt());
			stmt.setString(idx++, food.getNutr_cont1());		
			stmt.setString(idx++, food.getNutr_cont2());		
			stmt.setString(idx++, food.getNutr_cont3());		
			stmt.setString(idx++, food.getNutr_cont4());		
			stmt.setString(idx++, food.getNutr_cont5());		
			stmt.setString(idx++, food.getNutr_cont6());		
			stmt.setString(idx++, food.getNutr_cont7());		
			stmt.setString(idx++, food.getNutr_cont8());		
			stmt.setString(idx++, food.getNutr_cont9());
			stmt.setInt(idx++, food.getBgn_year());
			stmt.setString(idx++, food.getName());
			System.out.println(stmt);
			stmt.executeUpdate();
		} finally {
			DBUtil.close(stmt);
			DBUtil.close(con);
		}
	}

	public void remove(int code) throws SQLException {

	}

	public List<Food> searchAll2(String type, String condition) throws SQLException {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet  rs  = null;
		System.out.println("type은" + type);
		System.out.println("condition은" + condition);
		try {
			con = DBUtil.getConnection();
			String sql = " select * from food ";
			if(type.equals("name")) {
				sql += " where name like ? ";
				stmt = con.prepareStatement(sql);
				stmt.setString(1, "%"+ condition + "%");
			}else if(type.equals("material")) {
				sql += " where material like ? ";
				stmt = con.prepareStatement(sql);
				stmt.setString(1, "%"+ condition + "%");
			}else if(type.equals("code")) {
				sql += " where code = ? ";
				stmt = con.prepareStatement(sql);
				stmt.setInt(1, Integer.parseInt(condition));
			}
			System.out.println(stmt);
			rs = stmt.executeQuery();
			
			List<Food> foods = new LinkedList<Food>();
			while(rs.next()) {
				foods.add(new Food(rs.getInt("code")
						,rs.getString("name")
						,rs.getString("maker")
						,rs.getString("material")
						,rs.getString("image")
						,rs.getString("serving_wt")
						,rs.getString("nutr_cont1")
						,rs.getString("nutr_cont2")
						,rs.getString("nutr_cont3")
						,rs.getString("nutr_cont4")
						,rs.getString("nutr_cont5")
						,rs.getString("nutr_cont6")
						,rs.getString("nutr_cont7")
						,rs.getString("nutr_cont8")
						,rs.getString("nutr_cont9")
						,rs.getInt("bgn_year")
						,rs.getString("animal_plant")));
			}
			return foods;
		} finally {
		  DBUtil.close(rs);
		  DBUtil.close(stmt);
		  DBUtil.close(con);
		}
	}

}
