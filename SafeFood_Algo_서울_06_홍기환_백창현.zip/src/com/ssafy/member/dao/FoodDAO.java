package com.ssafy.member.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.member.dto.Food;

public interface FoodDAO {
	public Food search(String type, String condition)	throws SQLException;
	public List<Food> searchAll()	throws SQLException;
	public List<Food> searchAll2(String type, String condition)	throws SQLException;
	public void add(Food food)		throws SQLException;
	public void update(Food food)	throws SQLException;
	public void remove(int code)	throws SQLException;
}
