package com.ssafy.member.service;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.member.dao.FoodDAO;
import com.ssafy.member.dao.FoodDAOImp;
import com.ssafy.member.dto.Food;
import com.ssafy.member.dto.FoodException;

public class FoodServiceImp implements FoodService {
	private FoodDAO dao = new FoodDAOImp();
	
	public Food search(String type, String condition) {
		try {
			Food food = dao.search(type, condition);
			if(food == null) {
				throw new FoodException("등록되지 않은 식품입니다.");
			}else {
			   return food;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new FoodException();
		}
	}

	public List<Food> searchAll() {
		try {
			return dao.searchAll();
		}catch (SQLException e) {
			throw new FoodException();
		}
	}
	
	public List<Food> searchAll2(String type, String condition) {
		try {
			return dao.searchAll2(type, condition);
		}catch (SQLException e) {
			throw new FoodException();
		}
	}

	public void add(Food food) {
		try {
			Food find = dao.search("name", food.getName());
			if(find != null) {
				throw new FoodException("이미 등록된 식품입니다.");
			}else {
				dao.add(food);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new FoodException();
		}
	}

	public void update(Food food) {
		try {
			Food find = dao.search("name", food.getName());
			if(find == null) {
				throw new FoodException("수정할 식품 정보가 없습니다.");
			}else {
				System.out.println(food.getName()+"업데이트 중");
				dao.update(food);
			}
		} catch (SQLException e) {
			throw new FoodException();
		}
	}

	public void remove(String code) {

	}

}
