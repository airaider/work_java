package com.ssafy.member.service;

import java.util.List;
import com.ssafy.member.dto.Food;

public interface FoodService {
	public Food search(String type, String condition);
	public List<Food> searchAll();
	public List<Food> searchAll2(String type, String condition);
	public void add(Food food);
	public void update(Food food);
	public void remove(String code);
}
