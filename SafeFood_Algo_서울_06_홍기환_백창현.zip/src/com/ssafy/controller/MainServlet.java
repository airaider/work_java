package com.ssafy.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;
import com.ssafy.member.dto.Food;
import com.ssafy.member.dto.Member;
import com.ssafy.member.service.FoodService;
import com.ssafy.member.service.FoodServiceImp;
import com.ssafy.member.service.MemberService;
import com.ssafy.member.service.MemberServiceImp;
import com.ssafy.util.KMP;

@WebServlet("*.do")
public class MainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memberService=new MemberServiceImp();
	private FoodService foodService = new FoodServiceImp(); 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "Main.jsp";
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String action = request.getServletPath();
		System.out.println(action);
		try {
			if(action!=null) {
				//분기 설정
				if(action.endsWith("login.do")) {
					url = login(request, response);
				}
				else if(action.endsWith("logout.do")) {
					url = logout(request, response);
				}
				else if(action.endsWith("memberregit.do")) {
					url = memregit(request, response);
				}
				else if(action.endsWith("memberinfo.do")) {
					url = meminfo(request, response);
				}
				else if(action.endsWith("updateMem.do")) {
					url = memupdate(request, response);
				}
				else if(action.endsWith("delete.do")) {
					url = delete(request, response);
				}
				else if(action.endsWith("main.do")) {
					url = mainList(request, response);
				}
				else if(action.endsWith("search.do")) {
					url = searchFood(request, response);
				}
				else if(action.endsWith("foodlist.do")) {
					url = foodList(request, response);
				}
				else if(action.endsWith("test.do")) {
					url = test(request, response);
				}
				else if(action.endsWith("sort.do")) {
					url = sort(request, response);
				}
				else if(action.endsWith("filter.do")) {
					url = filter(request, response);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", e.getMessage());
			url = "ErrorHandler.jsp";
		}
		if(url.startsWith("{") ||url.startsWith("[") ) {
			response.setContentType("application/json;charset=utf-8");
			response.getWriter().append(url);
		}else if(url.startsWith("redirect")) {
			response.sendRedirect(url.substring(url.indexOf(":")+1));
		}else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
	private String filter(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		String material = memberService.search((String)session.getAttribute("id")).getMaterial();
		String[] mat = material.split(",");
		List<Food> result = new LinkedList<Food>();
		List<Food> food = foodService.searchAll();
		
		for (int i = 0, size=food.size(); i < size; i++) {
			String input = food.get(i).getMaterial()+ food.get(i).getName();
			if(!KMP.KMPSearch(input,mat)) {
				result.add(food.get(i));
			}
		}
		request.setAttribute("list", result);
		return "Main.jsp";
	}
	private String sort(HttpServletRequest request, HttpServletResponse response) {
		String type = request.getParameter("sort");
		String tt = request.getParameter("type");
		System.out.println(tt);
		System.out.println(type);
		
		List<Food> food = foodService.searchAll();
		switch (type) {
		case "no":
			
			break;
		case "name":
			Collections.sort(food, new Comparator<Food>() {
				@Override
				public int compare(Food o1, Food o2) {
					return o1.getName().compareTo(o2.getName());
				}
			});
			break;
		case "kal":
			Collections.sort(food, new Comparator<Food>() {
				@Override
				public int compare(Food o1, Food o2) {
					return o1.getNutr_cont1().compareTo(o2.getNutr_cont1());
				}
			});
			break;
		default:
			break;
		}
		if(tt.equals("내림차순")) {
			System.out.println("!!");
			Collections.reverse(food);
		}
		request.setAttribute("list", food);
		return "Main.jsp";
		
	}
	private String test(HttpServletRequest request, HttpServletResponse response) {
		String name = request.getParameter("name");
		System.out.println(name);
		request.setAttribute("f", foodService.search("name", name));
		return "detailInfo.jsp";
	}
	private String foodList(HttpServletRequest request, HttpServletResponse response) {
		request.setAttribute("list", foodService.searchAll());
		return "foodlist.jsp";
	}
	private String searchFood(HttpServletRequest request, HttpServletResponse response) {
		String type = request.getParameter("sel1");
		String condition = request.getParameter("keyword");
		System.out.println(type + "  " + condition);
		request.setAttribute("list", foodService.searchAll2(type, condition));
		System.out.println(foodService.searchAll2(type, condition));
		System.out.println(request.getAttribute("list"));
		
		return "foodlist.jsp";
	}
	private String mainList(HttpServletRequest request, HttpServletResponse response) {
		
		request.setAttribute("list", foodService.searchAll());	
		System.out.println(request.getAttribute("list"));
		return "Main.jsp";
	}
	private String delete(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		memberService.remove((String)session.getAttribute("id"));
		return "logout.do";
	}
	private String memupdate(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String phone = request.getParameter("phoneNumber");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String[] alergy = request.getParameterValues("material");
		String material="";
		for (String string : alergy) {
			material+=string+",";
		}
		System.out.println(material);
		Member member = new Member(id, password, name, email, phone, address, material);
		memberService.update(member);
		return "memberinfo.do";
	}
	private String meminfo(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		System.out.println((String)session.getAttribute("id"));
		session.setAttribute("member", memberService.search((String)session.getAttribute("id")));
		return "redirect:myInfo.jsp";
	}
	private String memregit(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String phone = request.getParameter("phoneNumber");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String[] alergy = request.getParameterValues("material");
		String material="";
		for (String string : alergy) {
			material+=string+",";
		}
		System.out.println(material);
		Member member = new Member(id, password, name, email, phone, address, material);
		memberService.add(member);
		return "redirect:start.jsp";
	}
	private String logout(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.invalidate();
		System.out.println("session invalidate");
		return "redirect:start.jsp";
	}
	private String login(HttpServletRequest request, HttpServletResponse response) {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println(id+","+pw);
		
		try {
			memberService.login(id, pw);
			addToSession(request, "id", id);  
			Cookie cookie = new Cookie("id", id);
			cookie.setMaxAge(100000000);
			response.addCookie(cookie);
			System.out.println("login success!!");
			return "redirect:start.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", e.getMessage());
			return "main.do?action=loginform.do";
		}
		
	}
	
	private void addToSession(HttpServletRequest request, String key, Object value) {
		HttpSession session = request.getSession();
		session.setAttribute(key, value);
	}
	
	

}











