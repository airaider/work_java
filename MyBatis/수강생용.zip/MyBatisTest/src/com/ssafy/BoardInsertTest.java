package com.ssafy;

import java.util.ArrayList;
import java.util.List;

import com.ssafy.model.dto.Board;
import com.ssafy.model.dto.FileBean;
import com.ssafy.model.service.BoardService;
import com.ssafy.model.service.BoardServiceImp;

public class BoardInsertTest {

	public static void main(String[] args) {
		BoardService service = new BoardServiceImp();
		
		ArrayList<FileBean> files = new ArrayList<FileBean>();
		files.add(new FileBean("test3.txt", "test3.txt", 0));
		files.add(new FileBean("test4.txt", "test4.txt", 0));
		Board board = new Board(0, "ncia", "Mybatis test11111", "", "transaction1111");
		board.setFiles(files);
		service.insertBoard(board);
		
	}
}
