package com.ssafy;

import com.ssafy.model.dao.MemberDao;
import com.ssafy.model.dao.MemberDaoImp;
import com.ssafy.model.dto.Member;

public class MyBatisTest {

	public static void main(String[] args) {
		Member member = 
		 new Member("test", "1111", "테스트", "admin@test.com", "서울시");
		
		MemberDao dao = new MemberDaoImp();
//		try {
//			dao.insertMember(member);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		try {
			System.out.println(dao.search("ssafy"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
//			System.out.println(dao.searchAll());
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
