package com.ssafy.model.dao;

import java.sql.SQLException;
import java.util.List;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;

import com.ssafy.config.MyBatis;
import com.ssafy.model.dto.Member;
import com.ssafy.model.dto.PageBean;

public class MemberDaoImp implements MemberDao {
	private SqlSession session = MyBatis.getSqlSession();
	public void insertMember(Member member){

	}
	public void deleteMember(String id) {
	}
	public void updateMember(Member member){
	}
	public Member search(String id) {
		return null;
	}
	public List<Member> searchAll(PageBean bean) {
		return null;
	}
	public int count(PageBean bean){
		return 0;
	}
}





