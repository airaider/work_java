package com.ssafy.model.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import com.ssafy.config.MyBatis;
import com.ssafy.model.dao.BoardDao;
import com.ssafy.model.dao.BoardDaoImpl;
import com.ssafy.model.dto.Board;
import com.ssafy.model.dto.BoardException;
import com.ssafy.model.dto.PageBean;
import com.ssafy.util.DBUtil;
import com.ssafy.util.PageUtility;

public class BoardServiceImpl implements BoardService {
	BoardDao dao = new BoardDaoImpl();
	FileDao  fileDao = new FileDaoImp();
	public BoardServiceImpl() {
	}

	public BoardServiceImpl(BoardDao dao) {
		super();
		this.dao = dao;
	}

	public BoardDao getDao() {
		return dao;
	}

	public void setDao(BoardDao dao) {
		this.dao = dao;
	}

	@Override
	public void insertBoard(Board board) {
		
	}

	@Override
	public void updateBoard(Board board) {
		
	}

	@Override
	public void deleteBoard(String no) {
		
	}

	@Override
	public Board search(String no) {
		return null;
	}

	@Override
	public List<Board> searchAll(PageBean bean) {
		return null;
	}
}









