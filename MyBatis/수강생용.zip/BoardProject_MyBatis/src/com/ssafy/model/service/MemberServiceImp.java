package com.ssafy.model.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.ssafy.model.dao.MemberDAO;
import com.ssafy.model.dao.MemberDAOImp;
import com.ssafy.model.dto.Member;
import com.ssafy.model.dto.MemberException;
import com.ssafy.util.DBUtil;

public class MemberServiceImp implements MemberService {
	private MemberDAO dao = new MemberDAOImp();

	@Override
	public Member search(String id) {
		return null;
	}

	@Override
	public List<Member> searchAll() {
		return null;
	}

	public boolean login(String id, String pw) {
		return false;
	}

	public boolean checkID(String id) {
		return false;
	}

	public void update(Member member) {
		
	}

	public void remove(String id) {
		
	}

	public void add(Member member) {
		
	}
}
